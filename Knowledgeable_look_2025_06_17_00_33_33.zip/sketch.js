// --- Constantes Globais do Jogo ---
const CANVAS_WIDTH = 900;
const CANVAS_HEIGHT = 600;
const PLAYER_INITIAL_SIZE = 40;
const INITIAL_PLAYER_HEALTH = 100;
const MAX_PLAYER_HEALTH = 100;
const HEALTH_LOSS_ON_HIT = 25;
const HEALTH_GAIN_ON_SPECIAL_ITEM = 15;
const BASE_ITEM_SPAWN_RATE = 90; // Menor valor = mais itens
const BASE_OBSTACLE_SPAWN_RATE = 140; // Menor valor = mais obstáculos
const BASE_ELEMENT_SPEED = 3;
const BG_BASE_SPEED = 1.5;
const SCREEN_FLASH_INTENSITY = 150; // Intensidade do flash de colisão
const SCREEN_FLASH_DECAY = 15;     // Velocidade de desaparecimento do flash
const COLLECT_PARTICLE_COLOR = [255, 200, 0]; // Cor para partículas de coleta (laranja/amarelo)
const HIT_PARTICLE_COLOR = [100, 100, 100];   // Cor para partículas de colisão (cinza)
const PHASE_SCORE_TARGET = 300; // Pontuação necessária para mudar de fase

// --- Variáveis Globais do Jogo (Estado Mutável) ---
let gameState = 'start'; // 'start', 'playing', 'game_over', 'congrats'
let player;
let score = 0;
let currentPhase = 1; // 1: Campo, 2: Transição, 3: Cidade
let playerHealth = INITIAL_PLAYER_HEALTH;

// Arrays para elementos do jogo
let items = [];
let obstacles = [];
let particles = []; // Para as explosões de coleta/colisão

// Variáveis de cenário e efeitos
let bgX = 0; // Posição de rolagem do fundo para paralaxe
let urbanizationLevel = 0; // 0 = campo, 1 = cidade (progresso da urbanização)
let screenFlash = 0; // Controla a intensidade do flash vermelho na tela

// Elementos de cenário adicionais
let clouds = []; // Para nuvens no céu
let roadLines = []; // Para linhas da estrada

// Elementos DOM (botões)
let startButton;
let restartButton;
let menuButton;

// --- Pré-carregamento de Mídias (Imagens, Sons, etc.) ---
function preload() {
    // Você pode carregar imagens e sons aqui para o seu jogo.
    // Ex: playerImg = loadImage('assets/player.png');
    // Ex: collectSound = loadSound('assets/collect.mp3');
}

// --- Função de Configuração Inicial do p5.js ---
function setup() {
    createCanvas(CANVAS_WIDTH, CANVAS_HEIGHT);
    rectMode(CENTER);
    ellipseMode(CENTER);
    textAlign(CENTER, CENTER);
    noStroke();

    // No seu setup():

// Cria e configura o botão "Começar Jogo"
startButton = createButton('Começar Jogo');
// AQUI: Aumente o valor negativo para mover mais para a esquerda.
// Por exemplo, de -50 para -80 ou -100.
// Mantenha o valor Y que você já ajustou para baixo.
startButton.position(width / 2 - startButton.width / 2 - 80, height / 2 + 300); // Ajuste o -80 e mantenha o Y que você gosta
startButton.mousePressed(startGame);
startButton.class('game-button');
  
    // Mantenha os outros botões como estão, ou ajuste-os se precisar
    restartButton = createButton('Jogar Novamente');
    restartButton.position(width / 2 - restartButton.width / 2 - 100, height / 2 + 250);
    restartButton.mousePressed(startGame);
    restartButton.hide();
    restartButton.class('game-button');

    menuButton = createButton('Voltar ao Menu');
    menuButton.position(width / 2 - menuButton.width / 2 - 100, height / 2 + 170);
    menuButton.mousePressed(returnToMenu);
    menuButton.hide();
    menuButton.class('game-button');

    initializeScenarioElements();
}
// --- Função de Desenho Principal (Loop Contínuo) ---
function draw() {
    // Controla qual tela será desenhada com base no estado atual do jogo
    switch (gameState) {
        case 'start':
            drawStartScreen();
            break;
        case 'playing':
            updateGame(); // Atualiza a lógica do jogo
            drawGame();   // Desenha os elementos do jogo
            break;
        case 'game_over':
            drawGameOverScreen();
            break;
        case 'congrats':
            drawCongratsScreen();
            break;
    }
}

// --- Funções de Controle de Estado do Jogo ---

// Inicia um novo jogo, resetando todas as variáveis e escondendo botões de menu
function startGame() {
    score = 0;
    currentPhase = 1;
    playerHealth = INITIAL_PLAYER_HEALTH;
    urbanizationLevel = 0;
    items = [];
    obstacles = [];
    particles = [];
    bgX = 0; // Reseta a posição de rolagem do fundo
    screenFlash = 0; // Reseta o efeito de flash na tela

    player = new Player(100, height / 2, PLAYER_INITIAL_SIZE); // Cria uma nova instância do jogador
    gameState = 'playing'; // Muda o estado para "jogando"

    // Esconde todos os botões de menu/fim de jogo
    startButton.hide();
    restartButton.hide();
    menuButton.hide();

    initializeScenarioElements(); // Re-inicializa elementos do cenário para a nova partida
}

// Retorna à tela inicial do jogo
function returnToMenu() {
    gameState = 'start'; // Muda o estado para "início"
    startButton.show(); // Mostra o botão "Começar Jogo"
    restartButton.hide(); // Esconde os botões de fim de jogo
    menuButton.hide();
}

// Inicializa ou reinicializa os elementos de cenário (nuvens, linhas de estrada)
function initializeScenarioElements() {
    clouds = []; // Limpa quaisquer nuvens existentes
    for (let i = 0; i < 5; i++) {
        clouds.push({ x: random(width), y: random(50, 150), size: random(80, 150), speed: random(0.5, 1) });
    }
    roadLines = []; // Limpa quaisquer linhas de estrada existentes
    for (let i = 0; i < 10; i++) {
        roadLines.push({ x: i * 150, y: height * 0.85, width: 80, height: 10, speed: BASE_ELEMENT_SPEED * 0.7 });
    }
}
// --- Funções de Desenho das Telas (Interface do Usuário) ---

// Desenha a tela de início do jogo
function drawStartScreen() {
    background(100, 180, 255); // Fundo azul claro
    drawScenarioElements(true);

    // AQUI: Define a cor preta para o título
    fill(0); // Cor preta
    textSize(64);
    text("Conexão Campo & Cidade 🎉", width / 2, height / 2 - 200); // Título em preto

    // AQUI: Redefine a cor para preto antes dos próximos textos
    fill(255, 255, 255, 220); // Preto com leve transparência para o subtítulo
    textSize(28);
    text("Uma jornada pela transformação!", width / 2, height / 2 - 140);

    // --- Explicação do Jogo ---
    let yPos = height / 2 - 70; // Posição Y inicial para o texto explicativo

    // AQUI: Mantém esta linha em preto, como havíamos ajustado
    fill(0); // Define a cor preta
    textSize(18); // Tamanho da fonte para a explicação
    text("Bem-vindo ao jogo 'Conexão Campo & Cidade'!", width / 2, yPos);

    // AQUI: Volta a cor para preto para TODO o restante do texto de explicação
    fill(255); // Volta a cor para preto

    yPos += 25;
    text("Guie seu personagem por um cenário que evolui", width / 2, yPos);
    yPos += 25;
    text("do **Campo** à **Cidade**, coletando itens e desviando obstáculos.", width / 2, yPos);
    yPos += 50;

    text("🌾 **Fase 1: Campo** - Guie seu **Trator** e colete recursos naturais.", width / 2, yPos);
    yPos += 25;
    text("🚧 **Fase 2: Transição** - Seu **Carro** atravessa um cenário misto.", width / 2, yPos);
    yPos += 25;
    text("🏙️ **Fase 3: Cidade** - Pilote seu **Drone** em meio a inovações urbanas.", width / 2, yPos);
    yPos += 50;

    text("A dificuldade aumenta a cada fase!", width / 2, yPos);
    yPos += 25;
    text("Colete itens (pontos) e corações (💖) para recuperar vida.", width / 2, yPos);
    yPos += 25;
    text("Evite obstáculos para não perder vida.", width / 2, yPos);
    yPos += 50;

    // --- Instruções de Controle ---
    textSize(20);
    fill(255, 255, 255, 180); // Branco com mais transparência para as instruções (já estava assim)
    text("⬆️⬇️ Use W/S ou Setas para Mover.", width / 2, yPos + 10);
    
    // O botão "Começar Jogo" é gerenciado via hide/show no setup e startGame
}
    
    // O botão "Começar Jogo" é gerenciado via hide/show no setup e startGame

// Desenha os elementos do jogo durante a partida
function drawGame() {
    drawBackground();          // Desenha o fundo dinâmico (campo/cidade)
    drawScenarioElements(false); // Desenha elementos de cenário com lógica de jogo

    player.display(); // Desenha o jogador

    // Desenha todos os itens
    for (const item of items) {
        item.display();
    }
    // Desenha todos os obstáculos
    for (const obstacle of obstacles) {
        obstacle.display();
    }

    // Desenha e atualiza as partículas de efeitos
    for (let i = particles.length - 1; i >= 0; i--) {
        particles[i].update();
        particles[i].display();
        if (particles[i].isFinished()) {
            particles.splice(i, 1); // Remove partículas que já desapareceram
        }
    }

    displayUI(); // Exibe a interface do usuário (pontuação, vida, barra de fase)

    // Efeito de flash vermelho na tela em caso de colisão
    if (screenFlash > 0) {
        fill(255, 0, 0, screenFlash); // Cor vermelha com transparência
        rect(width / 2, height / 2, width, height);
        screenFlash -= SCREEN_FLASH_DECAY; // Diminui a intensidade do flash gradualmente
    }
}

// Desenha a tela de Game Over
function drawGameOverScreen() {
    background(0, 0, 0, 220); // Fundo escurecido e translúcido
    fill(255, 50, 50); // Cor do texto: vermelho
    textSize(72);
    text("FIM DE JOGO 😭", width / 2, height / 2 - 80);
    fill(255); // Cor do texto: branco
    textSize(40);
    text("Você não conseguiu completar a conexão!", width / 2, height / 2 - 20);
    textSize(32);
    text("Pontuação Final: " + score, width / 2, height / 2 + 20);

    // Mostra os botões para reiniciar ou voltar ao menu
    restartButton.show();
    menuButton.show();
}

// Desenha a tela de "Parabéns!" (jogo completado)
function drawCongratsScreen() {
    background(100, 200, 100, 220); // Fundo verde vibrante e translúcido
    fill(255); // Cor do texto: branco
    textSize(64);
    text("PARABÉNS! VOCÊ FEZ A CONEXÃO! 🥳", width / 2, height / 2 - 80);
    textSize(36);
    text("Sua jornada pela transformação foi um sucesso!", width / 2, height / 2 - 20);
    textSize(32);
    text("Pontuação Total: " + score, width / 2, height / 2 + 20);

    // Mostra os botões para jogar novamente ou voltar ao menu
    restartButton.show();
    menuButton.show();
}

// --- Funções de Lógica do Jogo ---

// Atualiza o estado do jogo a cada frame
function updateGame() {
    // Calcula o nível de urbanização baseado na pontuação total acumulada
    // Se o jogo tem 3 fases de 300 pontos, o total é 900.
    // O nível de urbanização vai de 0 (início) a 1 (pontuação total para completar o jogo).
    urbanizationLevel = constrain(score / (PHASE_SCORE_TARGET * 3), 0, 1);

    player.update(); // Atualiza a posição e estado do jogador

    // Calcula o fator de dificuldade: aumenta a velocidade e frequência de spawns
    // A dificuldade aumenta em 100% (dobro da velocidade, metade do spawn rate) ao atingir 100% de urbanização.
    let difficultyMultiplier = 1 + urbanizationLevel * 1;

    let currentElementSpeed = BASE_ELEMENT_SPEED * difficultyMultiplier; // Velocidade dos elementos (itens/obstáculos)
    let currentItemSpawnRate = max(30, BASE_ITEM_SPAWN_RATE / difficultyMultiplier); // Frequência de itens (mínimo de 30 frames)
    let currentObstacleSpawnRate = max(60, BASE_OBSTACLE_SPAWN_RATE / difficultyMultiplier); // Frequência de obstáculos (mínimo de 60 frames)

    // Gera novos itens e obstáculos com base na dificuldade atual
    spawnElements(currentItemSpawnRate, currentObstacleSpawnRate, currentElementSpeed);
    // Atualiza a posição dos itens e obstáculos existentes
    updateElements(currentElementSpeed);

    checkCollisions();  // Verifica se o jogador colidiu com algo
    checkPhaseChange(); // Verifica se é hora de mudar de fase

    // Verifica se a vida do jogador chegou a zero, para Game Over
    if (playerHealth <= 0) {
        gameState = 'game_over'; // Muda o estado para "game_over"
        startButton.hide();       // Garante que o botão de início esteja escondido
        restartButton.show();     // Mostra os botões de fim de jogo
        menuButton.show();
    }
}

// Desenha o fundo do jogo com efeito de paralaxe e transição rural/urbano
function drawBackground() {
    // Cores base para o céu e o chão (campo e cidade)
    const skyColorRural = color(135, 206, 235); // Azul claro para o céu rural
    const skyColorCity = color(40, 50, 70);     // Azul escuro/cinza para o céu da cidade
    const groundColorRural = color(100, 200, 100); // Verde para o campo
    const groundColorCity = color(40, 40, 50);     // Cinza escuro para o asfalto

    // Faz a transição de cores do céu e do chão com base no nível de urbanização
    const currentSkyColor = lerpColor(skyColorRural, skyColorCity, urbanizationLevel);
    const currentGroundColor = lerpColor(groundColorRural, groundColorCity, urbanizationLevel);

    background(currentSkyColor); // Desenha o céu

    fill(currentGroundColor); // Desenha o "chão" ou "estrada"
    rect(width / 2, height * 0.85, width, height * 0.3);

    // Efeito de paralaxe para elementos de fundo (árvores/prédios)
    // A velocidade do fundo aumenta com a urbanização, para dar sensação de movimento de cidade
    const currentBgSpeed = BG_BASE_SPEED * (1 + urbanizationLevel * 0.5);
    bgX -= currentBgSpeed;
    if (bgX < -width) { // Se o fundo saiu da tela, reseta para criar um loop infinito
        bgX = 0;
    }

    push(); // Salva o estado atual da matriz de transformação
    translate(bgX, 0); // Aplica a translação para o efeito de rolagem

    // Elementos rurais (árvores que desaparecem com a urbanização)
    // A opacidade das árvores diminui mais rapidamente (multiplicador de 3)
    fill(lerpColor(color(50, 150, 50), color(50, 50, 50, 0), urbanizationLevel * 3));
    const trunkColorRural = lerpColor(color(120, 70, 20), color(50, 50, 50, 0), urbanizationLevel * 3);
    for (let i = 0; i < 7; i++) {
        const treeBaseY = height * 0.7 + sin(frameCount * 0.01 + i * 0.5) * 10; // Adiciona um pequeno movimento oscilante
        triangle(i * 180 + (bgX % 360), treeBaseY - 60,
                 i * 180 + (bgX % 360) - 30, treeBaseY,
                 i * 180 + (bgX % 360) + 30, treeBaseY); // Copa triangular
        fill(trunkColorRural); // Cor do tronco
        rect(i * 180 + (bgX % 360), treeBaseY + 15, 12, 40); // Tronco
        fill(lerpColor(color(50, 150, 50), color(50, 50, 50, 0), urbanizationLevel * 3)); // Reseta a cor para a copa para o próximo ciclo
    }

    // Elementos urbanos (prédios que surgem com a urbanização)
    // A cor dos prédios transita de invisível para sólida
    const buildingColor = lerpColor(color(150, 150, 150, 0), color(120, 120, 130), (urbanizationLevel - 0.05) * 2);
    if (urbanizationLevel > 0.03) { // Começa a desenhar prédios a partir de um pequeno nível de urbanização
        fill(buildingColor);
        for (let i = 0; i < 15; i++) {
            const h = map(noise(i * 0.1 + frameCount * 0.005), 0, 1, 150, 400); // Altura variada usando ruído
            const buildingX = i * 120 + 60 + (bgX * 0.7); // Prédios se movem mais devagar para efeito de paralaxe
            rect(buildingX, height - h / 2, 100, h); // Desenha o prédio

            // Luzes piscando nos prédios (apenas na cidade avançada)
            if (urbanizationLevel > 0.7 && random() < 0.05) { // 5% de chance de piscar
                fill(255, 255, 0, random(50, 200)); // Amarelo/branco com transparência
                rect(buildingX + random(-40, 40), height - h + random(20, h - 20), 10, 10);
            }
        }
    }
    pop(); // Restaura o estado original da matriz de transformação
}

// Desenha elementos de cenário como nuvens e linhas de estrada
// 'isMenuScreen' ajusta a velocidade e transparência para a tela de menu
function drawScenarioElements(isMenuScreen) {
    // Nuvens (mais visíveis no campo e no menu)
    for (let cloud of clouds) {
        // Se for a tela de menu, a nuvem é totalmente visível; caso contrário, desaparece com a urbanização
        let cloudAlpha = isMenuScreen ? 255 : map(urbanizationLevel, 0, 0.5, 255, 0);
        fill(255, cloudAlpha); // Cor branca com transparência ajustada
        ellipse(cloud.x, cloud.y, cloud.size * 1.2, cloud.size * 0.8);
        ellipse(cloud.x + cloud.size * 0.3, cloud.y - cloud.size * 0.2, cloud.size * 0.8, cloud.size * 0.6);
        ellipse(cloud.x - cloud.size * 0.3, cloud.y - cloud.size * 0.1, cloud.size * 0.9, cloud.size * 0.7);
        // Velocidade da nuvem: mais lenta no menu, e diminui com a urbanização no jogo
        cloud.x -= cloud.speed * (isMenuScreen ? 0.2 : (1 - urbanizationLevel));
        if (cloud.x < -cloud.size * 1.5) { // Quando a nuvem sai da tela, reposiciona-a no lado direito
            cloud.x = width + random(50, 200);
            cloud.y = random(50, 150);
        }
    }

    // Linhas de estrada (mais visíveis na cidade)
    for (let i = roadLines.length - 1; i >= 0; i--) {
        let line = roadLines[i];
        // Transparência das linhas: levemente visíveis no menu, aparecem mais na transição para cidade
        let lineAlpha = isMenuScreen ? 50 : map(urbanizationLevel, 0.3, 1, 0, 255);
        fill(255, 255, 255, lineAlpha); // Cor branca com transparência
        rect(line.x, line.y, line.width, line.height);
        // Velocidade da linha: mais lenta no menu, e aumenta com a urbanização no jogo
        line.x -= line.speed * (isMenuScreen ? 0.3 : (1 + urbanizationLevel * 0.5));
        if (line.x < -line.width / 2) { // Quando a linha sai da tela, reposiciona-a no lado direito
            line.x = width + random(50, 100);
        }
    }
}

// Gera novos itens e obstáculos com base na taxa de spawn e velocidade atual
function spawnElements(currentItemSpawnRate, currentObstacleSpawnRate, elementSpeed) {
    // Gerar itens
    if (frameCount % floor(currentItemSpawnRate) === 0) {
        const randY = random(height * 0.2, height * 0.8); // Posição Y aleatória
        const itemSize = random(25, 35);                  // Tamanho aleatório
        let itemType;
        let itemEmoji;

        // Conjuntos de emojis para cada tipo de fase
        const ruralEmojis = ['🍎', '🥕', '🌻', '🐞', '🍄', '🌳', '💧'];
        const mixedEmojis = ['🌾', '⚙️', '💡', '🌳', '🚧', '🚕', '📱'];
        const cityEmojis = ['📱', '💻', '🍕', '🏢', '🚕', '💡', '🔋'];

        // 15% de chance de spawnar um item de vida (apenas a partir da fase 2)
        if (random() < 0.15 && currentPhase >= 2) {
            itemType = 'item_health';
            itemEmoji = '💖'; // Coração para item de vida
        } else {
            // Define o tipo e emoji do item com base na fase atual
            if (currentPhase === 1) { // Campo
                itemType = 'item_rural';
                itemEmoji = random(ruralEmojis);
            } else if (currentPhase === 2) { // Transição (mistura de itens rurais e urbanos)
                const combinedEmojis = [...ruralEmojis, ...cityEmojis]; // Combina os arrays de emojis
                itemType = random(['item_rural', 'item_city']); // Tipo pode ser rural ou cidade
                itemEmoji = random(combinedEmojis);
            } else { // Cidade
                itemType = 'item_city';
                itemEmoji = random(cityEmojis);
            }
        }
        items.push(new GameElement(width, randY, itemType, itemSize, itemEmoji, elementSpeed));
    }

    // Gerar obstáculos
    if (frameCount % floor(currentObstacleSpawnRate) === 0) {
        const randY = random(height * 0.2, height * 0.8);
        const obstacleSize = random(40, 60);
        let obstacleType;

        // Define o tipo de obstáculo com base na fase atual
        if (currentPhase === 1) { // Campo
            obstacleType = 'obstacle_rural';
        } else if (currentPhase === 2) { // Transição (mistura)
            obstacleType = random(['obstacle_rural', 'obstacle_city']);
        } else { // Cidade
            obstacleType = 'obstacle_city';
        }
        obstacles.push(new GameElement(width, randY, obstacleType, obstacleSize, '', elementSpeed));
    }
}

// Atualiza a posição e remove elementos que saem da tela
function updateElements(speed) {
    // Itera de trás para frente para remover elementos de forma segura
    for (let i = items.length - 1; i >= 0; i--) {
        items[i].speed = speed; // Aplica a velocidade dinâmica
        items[i].update();
        if (items[i].isOffscreen()) {
            items.splice(i, 1); // Remove o item se estiver fora da tela
        }
    }

    for (let i = obstacles.length - 1; i >= 0; i--) {
        obstacles[i].speed = speed; // Aplica a velocidade dinâmica
        obstacles[i].update();
        if (obstacles[i].isOffscreen()) {
            obstacles.splice(i, 1); // Remove o obstáculo se estiver fora da tela
        }
    }
}

// Verifica colisões entre o jogador, itens e obstáculos
function checkCollisions() {
    // Colisão com itens
    for (let i = items.length - 1; i >= 0; i--) {
        const item = items[i];
        // Colisão baseada na distância entre os centros (simplificada para círculos)
        if (dist(player.x, player.y, item.x, item.y) < player.size / 2 + item.size / 2 - 10) {
            if (item.type === 'item_health') {
                playerHealth = min(MAX_PLAYER_HEALTH, playerHealth + HEALTH_GAIN_ON_SPECIAL_ITEM); // Ganha vida, limitado ao máximo
            } else {
                score += 15; // Aumenta a pontuação para itens normais
            }
            // Adiciona partículas visuais na coleta
            for (let j = 0; j < 10; j++) {
                particles.push(new Particle(item.x, item.y, color(COLLECT_PARTICLE_COLOR[0], COLLECT_PARTICLE_COLOR[1], COLLECT_PARTICLE_COLOR[2], random(100, 200))));
            }
            items.splice(i, 1); // Remove o item coletado
        }
    }

    // Colisão com obstáculos
    for (let i = obstacles.length - 1; i >= 0; i--) {
        const obstacle = obstacles[i];
        if (dist(player.x, player.y, obstacle.x, obstacle.y) < player.size / 2 + obstacle.size / 2 - 10) {
            playerHealth -= HEALTH_LOSS_ON_HIT; // Perde vida
            screenFlash = SCREEN_FLASH_INTENSITY; // Ativa o flash vermelho na tela
            // Adiciona partículas de colisão (cinza/escuro)
            for (let j = 0; j < 15; j++) {
                particles.push(new Particle(obstacle.x, obstacle.y, color(HIT_PARTICLE_COLOR[0], HIT_PARTICLE_COLOR[1], HIT_PARTICLE_COLOR[2], random(100, 200))));
            }
            obstacles.splice(i, 1); // Remove o obstáculo colidido
            // Sem 'break' aqui, o jogador pode colidir com múltiplos obstáculos se estiverem próximos
        }
    }
}

// Verifica se a pontuação atual é suficiente para mudar de fase ou completar o jogo
function checkPhaseChange() {
    if (score >= PHASE_SCORE_TARGET) {
        if (currentPhase < 3) { // Se não for a última fase (ainda tem fases para avançar)
            currentPhase++;       // Avança para a próxima fase
            score = 0;            // Reseta a pontuação para a nova fase
            initializeScenarioElements(); // Re-inicializa elementos do cenário para a nova fase (ex: nuvens/linhas)
        } else { // Se já for a última fase (Fase 3) e atingiu a pontuação
            gameState = 'congrats'; // Muda o estado para "congrats" (jogo completado)
            startButton.hide();       // Esconde o botão de início
            restartButton.show();     // Mostra os botões de fim de jogo
            menuButton.show();
        }
    }
}

// Exibe a interface do usuário (pontuação, barra de vida, indicador de fase, barra de progresso)
function displayUI() {
    fill(255); // Cor do texto: branco
    textSize(24);
    text("Pontos: " + score, width - 120, 30); // Pontuação no canto superior direito

    // Barra de Vida
    const healthBarWidth = 150;
    const healthBarHeight = 20;
    const healthX = 150;
    const healthY = 30;
    fill(50); // Fundo da barra de vida (cinza escuro)
    rect(healthX, healthY, healthBarWidth, healthBarHeight, 5); // Retângulo arredondado
    const currentHealthWidth = map(playerHealth, 0, MAX_PLAYER_HEALTH, 0, healthBarWidth); // Largura da vida atual
    // Cor da vida: transita de verde (vida cheia) para vermelho (pouca vida)
    fill(lerpColor(color(255, 0, 0), color(0, 255, 0), playerHealth / MAX_PLAYER_HEALTH));
    rect(healthX - healthBarWidth / 2 + currentHealthWidth / 2, healthY, currentHealthWidth, healthBarHeight, 5);
    fill(255); // Cor do texto da vida: branco
    textSize(20);
    text("Vida: " + playerHealth, healthX, healthY);

    // Indicador de Fase
    let phaseText = "";
    let phaseColor;
    // Define o texto e a cor da fase com base na fase atual
    switch (currentPhase) {
        case 1:
            phaseText = "Fase 1: Campo 🌾";
            phaseColor = color(0, 150, 0); // Verde para o campo
            break;
        case 2:
            phaseText = "Fase 2: Transição 🚧";
            phaseColor = color(255, 150, 0); // Laranja para a transição
            break;
        case 3:
            phaseText = "Fase 3: Cidade 🏙️";
            phaseColor = color(80, 80, 90); // Cinza escuro para a cidade
            break;
    }
    fill(phaseColor); // Aplica a cor da fase
    textSize(24);
    text(phaseText, width / 2, 30); // Texto da fase no centro superior

    // Barra de Progresso da Fase
    const progressBarWidth = 300;
    const progressBarHeight = 15;
    const progressX = width / 2;
    const progressY = 60;
    fill(150, 150, 150, 100); // Fundo da barra de progresso (cinza claro transparente)
    rect(progressX, progressY, progressBarWidth, progressBarHeight, 5);
    const currentProgressWidth = map(score, 0, PHASE_SCORE_TARGET, 0, progressBarWidth); // Largura do progresso atual
    fill(phaseColor); // Cor da barra de progresso acompanha a cor da fase
    rect(progressX - progressBarWidth / 2 + currentProgressWidth / 2, progressY, currentProgressWidth, progressBarHeight, 5);
    fill(255); // Cor do texto: branco
    textSize(16);
    text("Próxima Fase: " + (PHASE_SCORE_TARGET - score) + " pts", progressX, progressY + 25); // Pontos restantes para a próxima fase
}

// --- Funções de Controle de Input ---
function keyPressed() {
    if (gameState === 'playing') { // Só permite mover o jogador se o jogo estiver "jogando"
        if (keyCode === UP_ARROW || key === 'w' || key === 'W') {
            player.move(-5)//Move para cima
        } else if (keyCode === DOWN_ARROW || key === 's' || key === 'S') {
            player.move(5)//Move para baixo
        }
    }
    // A funcionalidade de reiniciar com 'R' foi removida, agora usamos botões
}

// --- Classes do Jogo ---

// Classe Player (Jogador)
class Player {
    constructor(x, y, size) {
        this.x = x;      // Posição X
        this.y = y;      // Posição Y
        this.size = size; // Tamanho
        this.speed = 8;  // Velocidade de movimento vertical
        this.initialColor = color(255, 100, 0); // Cor inicial (laranja vibrante)
    }

    update() {
        // Restringe a posição Y do jogador para que ele não saia da tela
        this.y = constrain(this.y, this.size / 2, height - this.size / 2);
    }

    display() {
        // A cor do jogador transita suavemente com o nível de urbanização
        const currentPlayerColor = lerpColor(this.initialColor, color(100, 150, 255), urbanizationLevel);
        fill(currentPlayerColor); // Aplica a cor atual do jogador

        push(); // Salva o estado atual da matriz de transformação
        translate(this.x, this.y); // Move o ponto de origem para a posição do jogador

        // Desenha o personagem com base na fase (trator -> carro -> drone)
        if (currentPhase === 1) { // Trator no campo
            rect(0, 0, this.size, this.size * 0.7); // Corpo retangular
            fill(50); // Cor das rodas
            ellipse(-this.size * 0.3, this.size * 0.3, this.size * 0.25); // Roda traseira
            ellipse(this.size * 0.3, this.size * 0.3, this.size * 0.18); // Roda dianteira
            fill(currentPlayerColor.levels[0] * 0.8, currentPlayerColor.levels[1] * 0.8, currentPlayerColor.levels[2] * 0.8); // Cor da cabine (um pouco mais escura)
            rect(0, -this.size * 0.3, this.size * 0.5, this.size * 0.2); // Cabine
        } else if (currentPhase === 2) { // Carro na transição
            rect(0, 0, this.size * 1.1, this.size * 0.6); // Corpo do carro (mais retangular e largo)
            fill(50); // Cor dos pneus
            ellipse(-this.size * 0.35, this.size * 0.2, this.size * 0.2); // Pneu
            ellipse(this.size * 0.35, this.size * 0.2, this.size * 0.2); // Pneu
            fill(180, 220, 255); // Cor da janela (azul claro)
            rect(0, -this.size * 0.15, this.size * 0.7, this.size * 0.25); // Janela
        } else { // Drone na cidade
            ellipse(0, 0, this.size * 0.8, this.size * 0.5); // Corpo oval principal
            fill(150); // Cor das asas/hastes
            rect(-this.size * 0.4, 0, this.size * 0.6, 5); // Asa esquerda
            rect(this.size * 0.4, 0, this.size * 0.6, 5); // Asa direita
            rect(0, -this.size * 0.2, 5, this.size * 0.6); // Haste central
            fill(50); // Cor das hélices
            ellipse(-this.size * 0.4, -this.size * 0.3, 15); // Hélice 1
            ellipse(this.size * 0.4, -this.size * 0.3, 15); // Hélice 2
        }
        pop(); // Restaura o estado da matriz de transformação
    }

    move(dir) {
        this.y += dir * this.speed; // Move o jogador para cima ou para baixo
    }
}

// Classe GameElement (para Itens e Obstáculos)
class GameElement {
    constructor(x, y, type, size, emoji = '', speed) {
        this.x = x;      // Posição X
        this.y = y;      // Posição Y
        this.type = type; // Tipo do elemento (ex: 'item_rural', 'obstacle_city')
        this.size = size; // Tamanho
        this.speed = speed; // Velocidade de movimento horizontal
        this.emoji = emoji; // Emoji (apenas para itens)
    }

    update() {
        this.x -= this.speed; // Move o elemento para a esquerda
    }

    display() {
        push(); // Salva o estado atual da matriz de transformação
        translate(this.x, this.y); // Move o ponto de origem para a posição do elemento

        if (this.type.startsWith('item')) {
            textSize(this.size); // Define o tamanho do texto para o emoji
            text(this.emoji, 0, 0); // Desenha o emoji
        } else { // Se for um obstáculo
            if (this.type === 'obstacle_rural') {
                fill(150, 100, 50); // Marrom para obstáculos rurais (pedras/troncos)
                rect(0, 0, this.size * 0.8, this.size * 0.8, 5); // Desenha um quadrado/retângulo arredondado
            } else if (this.type === 'obstacle_city') {
                fill(180); // Cinza para obstáculos urbanos (cones/blocos)
                triangle(0, -this.size / 2, -this.size / 2, this.size / 2, this.size / 2, this.size / 2); // Desenha um triângulo
            }
        }
        pop(); // Restaura o estado da matriz de transformação
    }

    isOffscreen() {
        return this.x < -this.size / 2; // Verifica se o elemento saiu completamente da tela
    }
}

// Classe Particle (para efeitos visuais de explosão/impacto)
class Particle {
    constructor(x, y, c) {
        this.x = x;      // Posição inicial X
        this.y = y;      // Posição inicial Y
        this.vx = random(-2, 2); // Velocidade horizontal aleatória
        this.vy = random(-2, 2); // Velocidade vertical aleatória
        this.alpha = 255; // Opacidade inicial (totalmente visível)
        this.color = c;   // Cor da partícula
        this.size = random(5, 15); // Tamanho aleatório
    }

    update() {
        this.x += this.vx; // Atualiza a posição X
        this.y += this.vy; // Atualiza a posição Y
        this.alpha -= 5;   // Diminui a opacidade gradualmente (fazendo a partícula desaparecer)
    }

    display() {
        noStroke(); // Remove a borda
        fill(this.color.levels[0], this.color.levels[1], this.color.levels[2], this.alpha); // Aplica a cor com transparência
        ellipse(this.x, this.y, this.size); // Desenha a partícula como um círculo
    }

    isFinished() {
        return this.alpha < 0; // Retorna true se a partícula já desapareceu completamente
    }
}